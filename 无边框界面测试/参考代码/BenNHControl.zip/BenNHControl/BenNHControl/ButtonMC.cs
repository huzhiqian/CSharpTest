﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace BenNHControl
{
    public enum ButtonType
    {
        Minimize,
        Maximization,
        Close
    }
    public partial class ButtonMC : UserControl
    {
        private Color lineColor = Color.Black;

        public Color LineColor
        {
            get { return lineColor; }
            set
            {
                lineColor = value;
                this.Invalidate();
            }
        }

        private ButtonType buttonType = ButtonType.Minimize;

        public ButtonType ButtonType
        {
            get { return buttonType; }
            set
            { 
                buttonType = value;
                this.Invalidate();
            }
        }


        private Color mouseEnterColor = Color.White;

        public Color MouseEnterColor
        {
            get { return mouseEnterColor; }
            set
            {
                mouseEnterColor = value;
                this.Invalidate();
            }
        }

        private Color mouseLeaveColor = Color.FromArgb(35, 44, 56);

        public Color MouseLeaveColor
        {
            get { return mouseLeaveColor; }
            set
            {
                mouseLeaveColor = value;
                this.Invalidate();
            }
        }

        private Color mouseUpColor = Color.White;

        public Color MouseUpColor
        {
            get { return mouseUpColor; }
            set
            {
                mouseUpColor = value;
                this.Invalidate();
            }
        }

        private Color mouseDownColor = Color.FromArgb(35, 44, 56);

        public Color MouseDownColor
        {
            get { return mouseDownColor; }
            set
            {
                mouseDownColor = value;
                this.Invalidate();
            }
        }


        public ButtonMC()
        {
            InitializeComponent();
        }

        private void ButtonMC_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            SolidBrush solidBrush = new SolidBrush(this.lineColor);
            g.SmoothingMode = SmoothingMode.AntiAlias;
            if (buttonType == BenNHControl.ButtonType.Close)//关闭按钮x
            {
                Point point = new Point(this.Width / 5 * 1, this.Height / 10 * 1);
                Point[] topTriangLePoints = new Point[5];
                topTriangLePoints[0] = point;
                topTriangLePoints[1] = new Point(this.Width / 10 * 9, this.Height / 10 * 8);
                topTriangLePoints[2] = new Point(this.Width / 5 * 4, this.Height / 10 * 9);
                topTriangLePoints[3] = new Point(this.Width / 10 * 1, this.Height / 5 * 1);
                topTriangLePoints[4] = new Point(this.Width / 10 * 2, this.Height / 10 * 1);

                Point point2 = new Point(this.Width / 5 * 4, this.Height / 10 * 1);
                Point[] topTriangLePoint2 = new Point[5];
                topTriangLePoint2[0] = point2;
                topTriangLePoint2[1] = new Point(this.Width / 10 * 9, this.Height / 5 * 1);
                topTriangLePoint2[2] = new Point(this.Width / 5 * 1, this.Height / 10 * 9);
                topTriangLePoint2[3] = new Point(this.Width / 10 * 1, this.Height / 10 * 8);
                topTriangLePoint2[4] = new Point(this.Width / 5 * 4, this.Height / 10 * 1);

                g.FillPolygon(solidBrush, topTriangLePoints);
                g.FillPolygon(solidBrush, topTriangLePoint2);
            }
            else if (buttonType == BenNHControl.ButtonType.Minimize)//最小化-
            {
                g.FillRectangle(solidBrush,this.Width/10*1,this.Height/5*2,this.Width/10*8,this.Height/6);
            }
            else if (buttonType == BenNHControl.ButtonType.Maximization)
            {
                Pen pen = new Pen(this.lineColor, this.Width/30*3);//定义了一个蓝色,宽度为的画笔
                SolidBrush solidBrush2 = new SolidBrush(this.BackColor);
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.DrawRectangle(pen,this.Width/6*1,this.Height/6*2,this.Width/6*4,this.Height/6*2);
                //g.DrawRectangle(pen, this.Width / 5 * 1, this.Height / 6 * 2, this.Width / 6 * 3, this.Height / 5 * 2);
                //g.FillRectangle(solidBrush2, this.Width / 5 * 1+1, this.Height / 6 * 2+1, this.Width / 6 * 3, this.Height / 5 * 2);
            }


           
        }

        private void ButtonMC_MouseEnter(object sender, EventArgs e)
        {
            this.BackColor = this.mouseEnterColor;
        }

        private void ButtonMC_MouseLeave(object sender, EventArgs e)
        {
            this.BackColor = this.mouseLeaveColor;
        }

        private void ButtonMC_MouseUp(object sender, MouseEventArgs e)
        {
            this.BackColor = this.mouseUpColor;
        }

        private void ButtonMC_MouseDown(object sender, MouseEventArgs e)
        {
            this.BackColor = this.mouseDownColor;
        }
    }
}
