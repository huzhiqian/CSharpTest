﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ControlTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSetState_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text.Trim() == "Gray")
            {
                this.benNHValve1.ValveBackColor = Color.Gray;
            }
            else if (comboBox1.Text.Trim() == "Green")
            {
                this.benNHValve1.ValveBackColor = Color.Green;
            }
            else
            {
                this.benNHValve1.ValveBackColor = Color.Red;
            }
            //this.benNHValve1.ValveBackColor = Color
        }

        private void buttonMC1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text.Trim() == "Gray")
            {
                this.benNHValve1.ValveBackColor = Color.Gray;
            }
            else if (comboBox1.Text.Trim() == "Green")
            {
                this.benNHValve1.ValveBackColor = Color.Green;
            }
            else
            {
                this.benNHValve1.ValveBackColor = Color.Red;
            }
        }
    }
}
