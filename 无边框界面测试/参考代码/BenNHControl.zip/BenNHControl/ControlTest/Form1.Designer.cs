﻿namespace ControlTest
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSetState = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.buttonMC5 = new BenNHControl.ButtonMC();
            this.buttonMC4 = new BenNHControl.ButtonMC();
            this.buttonMC3 = new BenNHControl.ButtonMC();
            this.buttonMC2 = new BenNHControl.ButtonMC();
            this.buttonMC1 = new BenNHControl.ButtonMC();
            this.benNHValve1 = new BenNHControl.BenNHValve();
            this.buttonMC6 = new BenNHControl.ButtonMC();
            this.SuspendLayout();
            // 
            // btnSetState
            // 
            this.btnSetState.Location = new System.Drawing.Point(242, 273);
            this.btnSetState.Name = "btnSetState";
            this.btnSetState.Size = new System.Drawing.Size(75, 36);
            this.btnSetState.TabIndex = 1;
            this.btnSetState.Text = "更改状态";
            this.btnSetState.UseVisualStyleBackColor = true;
            this.btnSetState.Click += new System.EventHandler(this.btnSetState_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Green",
            "Gray",
            "Unknown"});
            this.comboBox1.Location = new System.Drawing.Point(115, 273);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 20);
            this.comboBox1.TabIndex = 2;
            this.comboBox1.Text = "Green";
            // 
            // buttonMC5
            // 
            this.buttonMC5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(44)))), ((int)(((byte)(56)))));
            this.buttonMC5.ButtonType = BenNHControl.ButtonType.Minimize;
            this.buttonMC5.LineColor = System.Drawing.Color.Black;
            this.buttonMC5.Location = new System.Drawing.Point(267, 132);
            this.buttonMC5.MouseDownColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(44)))), ((int)(((byte)(56)))));
            this.buttonMC5.MouseEnterColor = System.Drawing.Color.White;
            this.buttonMC5.MouseLeaveColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(44)))), ((int)(((byte)(56)))));
            this.buttonMC5.MouseUpColor = System.Drawing.Color.White;
            this.buttonMC5.Name = "buttonMC5";
            this.buttonMC5.Size = new System.Drawing.Size(50, 50);
            this.buttonMC5.TabIndex = 7;
            // 
            // buttonMC4
            // 
            this.buttonMC4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(44)))), ((int)(((byte)(56)))));
            this.buttonMC4.ButtonType = BenNHControl.ButtonType.Maximization;
            this.buttonMC4.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonMC4.Location = new System.Drawing.Point(311, 38);
            this.buttonMC4.MouseDownColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(44)))), ((int)(((byte)(56)))));
            this.buttonMC4.MouseEnterColor = System.Drawing.Color.White;
            this.buttonMC4.MouseLeaveColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(44)))), ((int)(((byte)(56)))));
            this.buttonMC4.MouseUpColor = System.Drawing.Color.White;
            this.buttonMC4.Name = "buttonMC4";
            this.buttonMC4.Size = new System.Drawing.Size(30, 30);
            this.buttonMC4.TabIndex = 6;
            // 
            // buttonMC3
            // 
            this.buttonMC3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(44)))), ((int)(((byte)(56)))));
            this.buttonMC3.ButtonType = BenNHControl.ButtonType.Minimize;
            this.buttonMC3.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonMC3.Location = new System.Drawing.Point(260, 38);
            this.buttonMC3.MouseDownColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(44)))), ((int)(((byte)(56)))));
            this.buttonMC3.MouseEnterColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.buttonMC3.MouseLeaveColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(44)))), ((int)(((byte)(56)))));
            this.buttonMC3.MouseUpColor = System.Drawing.Color.White;
            this.buttonMC3.Name = "buttonMC3";
            this.buttonMC3.Size = new System.Drawing.Size(30, 30);
            this.buttonMC3.TabIndex = 5;
            // 
            // buttonMC2
            // 
            this.buttonMC2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(44)))), ((int)(((byte)(56)))));
            this.buttonMC2.ButtonType = BenNHControl.ButtonType.Close;
            this.buttonMC2.LineColor = System.Drawing.Color.Black;
            this.buttonMC2.Location = new System.Drawing.Point(186, 132);
            this.buttonMC2.MouseDownColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(44)))), ((int)(((byte)(56)))));
            this.buttonMC2.MouseEnterColor = System.Drawing.Color.White;
            this.buttonMC2.MouseLeaveColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(44)))), ((int)(((byte)(56)))));
            this.buttonMC2.MouseUpColor = System.Drawing.Color.White;
            this.buttonMC2.Name = "buttonMC2";
            this.buttonMC2.Size = new System.Drawing.Size(50, 50);
            this.buttonMC2.TabIndex = 4;
            // 
            // buttonMC1
            // 
            this.buttonMC1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(44)))), ((int)(((byte)(56)))));
            this.buttonMC1.ButtonType = BenNHControl.ButtonType.Close;
            this.buttonMC1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonMC1.Location = new System.Drawing.Point(204, 38);
            this.buttonMC1.MouseDownColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(44)))), ((int)(((byte)(56)))));
            this.buttonMC1.MouseEnterColor = System.Drawing.Color.White;
            this.buttonMC1.MouseLeaveColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(44)))), ((int)(((byte)(56)))));
            this.buttonMC1.MouseUpColor = System.Drawing.Color.White;
            this.buttonMC1.Name = "buttonMC1";
            this.buttonMC1.Size = new System.Drawing.Size(30, 30);
            this.buttonMC1.TabIndex = 3;
            this.buttonMC1.Click += new System.EventHandler(this.buttonMC1_Click);
            // 
            // benNHValve1
            // 
            this.benNHValve1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.benNHValve1.Location = new System.Drawing.Point(80, 59);
            this.benNHValve1.Name = "benNHValve1";
            this.benNHValve1.Size = new System.Drawing.Size(44, 46);
            this.benNHValve1.TabIndex = 0;
            this.benNHValve1.ValveBackColor = System.Drawing.Color.Green;
            // 
            // buttonMC6
            // 
            this.buttonMC6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(44)))), ((int)(((byte)(56)))));
            this.buttonMC6.ButtonType = BenNHControl.ButtonType.Minimize;
            this.buttonMC6.LineColor = System.Drawing.Color.LightGray;
            this.buttonMC6.Location = new System.Drawing.Point(54, 142);
            this.buttonMC6.MouseDownColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(44)))), ((int)(((byte)(56)))));
            this.buttonMC6.MouseEnterColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonMC6.MouseLeaveColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.buttonMC6.MouseUpColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.buttonMC6.Name = "buttonMC6";
            this.buttonMC6.Size = new System.Drawing.Size(30, 30);
            this.buttonMC6.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(387, 353);
            this.Controls.Add(this.buttonMC6);
            this.Controls.Add(this.buttonMC5);
            this.Controls.Add(this.buttonMC4);
            this.Controls.Add(this.buttonMC3);
            this.Controls.Add(this.buttonMC2);
            this.Controls.Add(this.buttonMC1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.btnSetState);
            this.Controls.Add(this.benNHValve1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private BenNHControl.BenNHValve benNHValve1;
        private System.Windows.Forms.Button btnSetState;
        private System.Windows.Forms.ComboBox comboBox1;
        private BenNHControl.ButtonMC buttonMC1;
        private BenNHControl.ButtonMC buttonMC2;
        private BenNHControl.ButtonMC buttonMC3;
        private BenNHControl.ButtonMC buttonMC4;
        private BenNHControl.ButtonMC buttonMC5;
        private BenNHControl.ButtonMC buttonMC6;

    }
}

